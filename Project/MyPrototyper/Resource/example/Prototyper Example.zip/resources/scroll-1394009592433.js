(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-6372fe38-3874-4015-9aac-77b75f14fc08 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-abbf570d-8795-46c6-ac05-58f32e93e24e .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-5a05c2d2-7645-472b-ab18-60d7df0f3942 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-bec90758-6901-497e-ab8b-7f3ea62618c7 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'multi' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 #s-Panel_1").overscroll({ showThumbs:false, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);