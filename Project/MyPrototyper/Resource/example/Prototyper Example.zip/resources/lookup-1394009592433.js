(function(window, undefined) {
  var dictionary = {
    "6372fe38-3874-4015-9aac-77b75f14fc08": "SideMenu",
    "abbf570d-8795-46c6-ac05-58f32e93e24e": "Splash Page",
    "5a05c2d2-7645-472b-ab18-60d7df0f3942": "Login imported",
    "bec90758-6901-497e-ab8b-7f3ea62618c7": "Detail page",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Master page",
    "0376ce03-a14c-452a-ba38-343544cd6ac4": "Template 1",
    "ad63ef25-6ca8-4f66-afd0-d09d1206b6ab": "iPhone4"
  };

  var uriRE = /^(\/#)?(screens|templates|masters)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);