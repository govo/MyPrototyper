//
//  MPTabBarController.h
//  MyPrototyper
//
//  Created by govo on 14-2-2.
//  Copyright (c) 2014年 me.govo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPTabBarController : UITabBarController

@end
