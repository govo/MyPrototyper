//
//  MPSimpleWebViewController.h
//  MyPrototyper
//
//  Created by govo on 14-2-15.
//  Copyright (c) 2014年 me.govo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPSimpleWebViewController : UIViewController
@property(copy,nonatomic) NSString *urlString;

@end
