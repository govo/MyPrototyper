//
//  MPSettingNavigationController.h
//  MyPrototyper
//
//  Created by govo on 14-2-4.
//  Copyright (c) 2014年 me.govo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPNavigationController : UINavigationController

@property(assign,nonatomic) BOOL isRotateable;
@property(assign,nonatomic) NSInteger orientationSupport;


@end
