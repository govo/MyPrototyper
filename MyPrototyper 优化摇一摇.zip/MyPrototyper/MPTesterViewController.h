//
//  MPTesterViewController.h
//  MyPrototyper
//
//  Created by govo on 14-2-16.
//  Copyright (c) 2014年 me.govo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPTesterViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *contentVIew;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end
